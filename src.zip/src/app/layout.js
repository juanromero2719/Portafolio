"use client";

import './globals.css';

// hooks
import { useState } from "react";

// componente
import ChatBot from './contact/components/chatbot';
import NavBar from './components/navbar';
import Footer from './components/footer';

export default function RootLayout({ children }) {

  const [isChatOpen, setIsChatOpen] = useState(false);

  const handleContactClick = () => {
    setIsChatOpen(true);
  };

  const handleChatClose = () => {
    setIsChatOpen(false);
  };

  return (
    <html lang="en">
      <body className="min-h-screen bg-gradient-animated bg-[length:400%_400%] animate-gradient-move">
        <NavBar />
        <main className="flex-grow">{children}</main>
        <ChatBot isOpen={isChatOpen} onClose={handleChatClose} />
        <Footer />
      </body>
    </html>
  );
}
